import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, "..");
const data = JSON.parse(await fs.readFile(path.join(here, "supplementary_workbook_data.json"), "utf8"));
const output = path.join(root, "tables", "Supplementary_Appendix_2_Tables.xlsx");
const qaDir = path.join(root, "qa_workbook_final");
await fs.mkdir(path.dirname(output), { recursive: true });
await fs.mkdir(qaDir, { recursive: true });

const names = [
  "README", "S1_Cohort_Map", "S2_Continuous", "S3_Transitions", "S4_Threshold_Audit",
  "S5_State_Structure", "S6_Reliability", "S7_Interval_Lengths", "S8_IPCW",
  "S9_Mortality", "S10_Adjustment", "S11_Prediction", "S12_Absolute_Risks",
  "S13_Sensitivities", "S14_Model_Failures", "S15_Model_Completion",
  "S16_Additional_Analyses", "S17_Reference_Locked", "S18_Reconciliation_Reliability",
];

function excelCol(n) {
  let s = "";
  while (n > 0) {
    n -= 1;
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26);
  }
  return s;
}

function widthFor(header) {
  const h = String(header).toLowerCase();
  if (h === "value") return 55;
  if (h === "item") return 28;
  if (/reason|covariate|handling|release|cognition|function|metric|source|action|issue|location|estimand|cohorts/.test(h)) return 38;
  if (/outcome|analysis|term|exposure|definition|status|record/.test(h)) return 26;
  if (/date|wave|cohort|domain|scale|mode|construct/.test(h)) return 16;
  if (/participant|interval|cluster|event|row|count|fold|iterations|n_total|n$/.test(h)) return 14;
  return 13;
}

function numberFormatFor(header) {
  const h = String(header).toLowerCase();
  if (/p_value|p-value|p value/.test(h)) return "0.0000";
  if (/percent|i2|skewness|alpha|omega|auc|brier|calibration|estimate|pooled|beta|risk|odds|ratio|ci_|ci |prediction|tau|std_error|weight|minimum|maximum|median|mean|quantile|cut|deviation|occupancy|mass|slope|intercept/.test(h)) return "0.0000";
  if (/n$|count|participants|intervals|clusters|events|rows|folds|iterations|wave/.test(h)) return "#,##0";
  return "General";
}

const workbook = Workbook.create();

for (let i = 0; i < data.sheets.length; i += 1) {
  const spec = data.sheets[i];
  const sheet = workbook.worksheets.add(names[i]);
  sheet.showGridLines = false;
  const cols = spec.columns.length;
  const lastCol = excelCol(cols);
  const lastRow = 4 + spec.rows.length;

  sheet.mergeCells(`A1:${lastCol}1`);
  sheet.getRange("A1").values = [[spec.title]];
  sheet.mergeCells(`A2:${lastCol}2`);
  sheet.getRange("A2").values = [[spec.note]];
  sheet.mergeCells(`A3:${lastCol}3`);
  sheet.getRange("A3").values = [[`Source: ${spec.source}`]];
  sheet.getRange(`A4:${lastCol}4`).values = [spec.columns];
  if (spec.rows.length) sheet.getRange(`A5:${lastCol}${lastRow}`).values = spec.rows;

  sheet.getRange(`A1:${lastCol}1`).format = {
    fill: "#1F4E78",
    font: { bold: true, color: "#FFFFFF", size: 14 },
    verticalAlignment: "center",
  };
  sheet.getRange(`A2:${lastCol}2`).format = {
    fill: "#D9EAF7",
    font: { color: "#203864", size: 10 },
    wrapText: true,
    verticalAlignment: "center",
  };
  sheet.getRange(`A3:${lastCol}3`).format = {
    fill: "#F2F2F2",
    font: { italic: true, color: "#666666", size: 9 },
    wrapText: true,
  };
  sheet.getRange(`A4:${lastCol}4`).format = {
    fill: "#4472C4",
    font: { bold: true, color: "#FFFFFF", size: 10 },
    wrapText: true,
    verticalAlignment: "center",
    borders: { preset: "outside", style: "thin", color: "#A6A6A6" },
  };
  if (spec.rows.length) {
    const body = sheet.getRange(`A5:${lastCol}${lastRow}`);
    body.format = {
      font: { color: "#222222", size: 9 },
      verticalAlignment: "center",
      borders: { insideHorizontal: { style: "thin", color: "#E6E6E6" } },
    };
    const table = sheet.tables.add(`A4:${lastCol}${lastRow}`, true, `Table_${String(i + 1).padStart(2, "0")}`);
    table.style = "TableStyleMedium2";
    table.showFilterButton = true;
  }

  sheet.getRange(`A1:${lastCol}1`).format.rowHeight = 28;
  sheet.getRange(`A2:${lastCol}2`).format.rowHeight = 38;
  sheet.getRange(`A3:${lastCol}3`).format.rowHeight = 24;
  sheet.getRange(`A4:${lastCol}4`).format.rowHeight = 32;
  sheet.freezePanes.freezeRows(4);
  if (cols > 5) sheet.freezePanes.freezeColumns(1);

  for (let j = 0; j < cols; j += 1) {
    const col = excelCol(j + 1);
    const header = spec.columns[j];
    const range = sheet.getRange(`${col}4:${col}${lastRow}`);
    range.format.columnWidth = widthFor(header);
    if (widthFor(header) >= 26) range.format.wrapText = true;
    range.format.numberFormat = numberFormatFor(header);
  }
  if (spec.rows.length <= 80) sheet.getRange(`A4:${lastCol}${lastRow}`).format.autofitRows();
}

const xlsx = await SpreadsheetFile.exportXlsx(workbook);
await xlsx.save(output);

const inspect = await workbook.inspect({ kind: "sheet,table", include: "id,name", maxChars: 12000 });
await fs.writeFile(path.join(root, "tables", "Supplementary_Appendix_2_Tables.inspect.ndjson"), inspect.ndjson, "utf8");
const errors = await workbook.inspect({
  kind: "match",
  searchTerm: "#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A",
  options: { useRegex: true, maxResults: 300 },
  summary: "final formula error scan",
});
await fs.writeFile(path.join(root, "tables", "Supplementary_Appendix_2_Tables.errors.ndjson"), errors.ndjson, "utf8");

for (let i = 0; i < names.length; i += 1) {
  const spec = data.sheets[i];
  const cols = spec.columns.length;
  const lastCol = excelCol(Math.min(cols, 14));
  const previewRows = Math.min(4 + spec.rows.length, 30);
  const preview = await workbook.render({
    sheetName: names[i],
    range: `A1:${lastCol}${previewRows}`,
    scale: 1,
    format: "png",
  });
  const bytes = new Uint8Array(await preview.arrayBuffer());
  await fs.writeFile(path.join(qaDir, `${names[i]}.png`), bytes);
}

console.log(`saved ${output}`);
console.log(`rendered ${names.length} sheet previews to ${qaDir}`);
