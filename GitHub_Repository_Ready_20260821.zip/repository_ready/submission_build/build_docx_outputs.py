#!/usr/bin/env python3
"""Build three visually consistent working DOCX files from revision Markdown."""

from __future__ import annotations

import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


ROOT = Path(__file__).resolve().parent
TEXT = ROOT / "text"
OUT = ROOT / "documents"
SOURCE_MANUSCRIPT = ROOT.parent / "Manuscript.docx"

BLUE = RGBColor(46, 116, 181)
DARK_BLUE = RGBColor(31, 77, 120)
MUTED = RGBColor(89, 89, 89)
RED = RGBColor(155, 28, 28)


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_widths(table, widths_inches: list[float]) -> None:
    table.autofit = False
    widths_twips = [round(width * 1440) for width in widths_inches]
    grid = table._tbl.tblGrid
    for existing in list(grid):
        grid.remove(existing)
    for width in widths_twips:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(width))
        grid.append(grid_col)
    for row in table.rows:
        tr_pr = row._tr.get_or_add_trPr()
        cant_split = tr_pr.find(qn("w:cantSplit"))
        if cant_split is None:
            tr_pr.append(OxmlElement("w:cantSplit"))
        for cell, width, width_twips in zip(row.cells, widths_inches, widths_twips):
            cell.width = Inches(width)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width_twips))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    tbl_pr = table._tbl.tblPr
    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), "9360")
    tbl_w.set(qn("w:type"), "dxa")
    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), "120")
    tbl_ind.set(qn("w:type"), "dxa")
    if table.rows:
        header_pr = table.rows[0]._tr.get_or_add_trPr()
        repeat = header_pr.find(qn("w:tblHeader"))
        if repeat is None:
            repeat = OxmlElement("w:tblHeader")
            header_pr.append(repeat)
        repeat.set(qn("w:val"), "true")


def set_table_font(table, size_points: float = 8.5) -> None:
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                for run in paragraph.runs:
                    run.font.name = "Calibri"
                    run.font.size = Pt(size_points)


def page_number(paragraph) -> None:
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = paragraph.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "end")
    run._r.extend([fld_char1, instr, fld_char2])


def configure_document(doc: Document, running_label: str) -> None:
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(1)
    section.bottom_margin = Inches(1)
    section.left_margin = Inches(1)
    section.right_margin = Inches(1)
    section.header_distance = Inches(0.492)
    section.footer_distance = Inches(0.492)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.line_spacing = 1.10
    for style_name, size, color, before, after in [
        ("Heading 1", 16, BLUE, 16, 8),
        ("Heading 2", 13, BLUE, 12, 6),
        ("Heading 3", 12, DARK_BLUE, 8, 4),
    ]:
        style = styles[style_name]
        style.font.name = "Calibri"
        style.font.size = Pt(size)
        style.font.color.rgb = color
        style.font.bold = True
        style.paragraph_format.space_before = Pt(before)
        style.paragraph_format.space_after = Pt(after)
        style.paragraph_format.keep_with_next = True
    styles["Title"].font.name = "Calibri"
    styles["Title"].font.size = Pt(20)
    styles["Title"].font.color.rgb = RGBColor(0, 0, 0)
    styles["Title"].font.bold = True
    styles["Title"].paragraph_format.space_after = Pt(12)
    styles["Caption"].font.name = "Calibri"
    styles["Caption"].font.size = Pt(9)

    header = section.header.paragraphs[0]
    header.text = running_label
    header.alignment = WD_ALIGN_PARAGRAPH.LEFT
    header.runs[0].font.size = Pt(8)
    header.runs[0].font.color.rgb = MUTED
    footer = section.footer.paragraphs[0]
    page_number(footer)
    for run in footer.runs:
        run.font.size = Pt(8)
        run.font.color.rgb = MUTED


def add_continuous_line_numbers(doc: Document) -> None:
    for section in doc.sections:
        sect_pr = section._sectPr
        existing = sect_pr.find(qn("w:lnNumType"))
        if existing is not None:
            sect_pr.remove(existing)
        line_numbers = OxmlElement("w:lnNumType")
        line_numbers.set(qn("w:countBy"), "1")
        line_numbers.set(qn("w:start"), "1")
        line_numbers.set(qn("w:restart"), "continuous")
        line_numbers.set(qn("w:distance"), "360")
        sect_pr.append(line_numbers)


def add_internal_banner(doc: Document, text: str) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    set_table_widths(table, [6.5])
    cell = table.cell(0, 0)
    set_cell_shading(cell, "FDE9E7")
    p = cell.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(text)
    run.bold = True
    run.font.color.rgb = RED
    run.font.size = Pt(10)


def add_authors(doc: Document) -> None:
    for text, bold in [
        ("Ming Li1,2,#, Xiaoyu Pan1,#, Xi Li1,#, Xian Wu1, Jiale Cai1, Lei Li1,*, Hailong Lu1,*", True),
        ("1 The Affiliated Hospital of Xuzhou Medical University, Xuzhou, Jiangsu, China.", False),
        ("2 National Demonstration Center for Experimental Basic Medical Science Education, Xuzhou Medical University, Xuzhou, Jiangsu, China.", False),
        ("# Equal contribution", False),
        ("* Correspondence: Lei Li, ligroup-999@126.com; Hailong Lu, victor5769@126.com", False),
    ]:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(3)
        run = p.add_run(text)
        run.bold = bold
        run.font.size = Pt(10)


def add_inline_markup(paragraph, text: str) -> None:
    # Minimal Markdown emphasis support.
    parts = re.split(r"(\*\*.*?\*\*|`.*?`)", text)
    for part in parts:
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            run.font.name = "Consolas"
            run.font.size = Pt(9.5)
        else:
            paragraph.add_run(part)


def add_rerun_callout(doc: Document, text: str) -> None:
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    set_table_widths(table, [6.5])
    cell = table.cell(0, 0)
    set_cell_shading(cell, "FFF4E5")
    p = cell.paragraphs[0]
    p.paragraph_format.space_after = Pt(0)
    run = p.add_run(text)
    run.bold = True
    run.font.color.rgb = RGBColor(122, 90, 0)
    run.font.size = Pt(9.5)


def parse_markdown(doc: Document, path: Path, manuscript: bool = False) -> None:
    lines = path.read_text(encoding="utf-8").splitlines()
    title_added = False
    authors_added = False
    for raw in lines:
        line = raw.strip()
        if not line:
            continue
        if line.startswith("# INTERNAL"):
            add_internal_banner(doc, line[2:].strip())
            continue
        if line.startswith("# ") and not title_added:
            p = doc.add_paragraph(style="Title")
            p.add_run(line[2:].strip())
            title_added = True
            if manuscript and not authors_added:
                add_authors(doc)
                authors_added = True
            continue
        if line.startswith("### "):
            doc.add_paragraph(line[4:].strip(), style="Heading 2")
            continue
        if line.startswith("## "):
            doc.add_paragraph(line[3:].strip(), style="Heading 1")
            continue
        if line.startswith("# "):
            doc.add_paragraph(line[2:].strip(), style="Heading 1")
            continue
        if line.startswith("[RERUN REQUIRED]") or line.startswith("RERUN REQUIRED:"):
            add_rerun_callout(doc, line)
            continue
        if line.startswith("- "):
            p = doc.add_paragraph(style="List Bullet")
            p.paragraph_format.left_indent = Inches(0.5)
            p.paragraph_format.first_line_indent = Inches(-0.25)
            p.paragraph_format.space_after = Pt(8)
            p.paragraph_format.line_spacing = 1.167
            add_inline_markup(p, line[2:])
            continue
        p = doc.add_paragraph()
        add_inline_markup(p, line)


def append_manuscript_tables(doc: Document) -> None:
    doc.add_paragraph("Table 1. Cohort and measurement summary", style="Heading 1")
    headers = ["Cohort", "Waves", "N ≥1", "N ≥2", "Intervals", "Cognition", "Function", "Death"]
    rows = [
        ["CHARLS", "1-5", "25,873", "23,474", "70,067", "4 tests", "11 items", "Yes"],
        ["ELSA", "1-9", "19,802", "15,388", "67,471", "2 tests", "13 items", "No*"],
        ["HRS", "5-15", "36,529", "33,000", "180,628", "27-point total", "11 items", "Yes"],
        ["KLoSA", "3-7", "9,216", "8,516", "29,954", "30-point K-MMSE", "17 help items", "Yes"],
        ["MHAS", "1-5", "26,837", "19,797", "53,922", "Memory + attention", "10 items", "Yes"],
        ["SHARE", "4-8", "117,831", "72,343", "121,528", "3 domains", "12 items", "Yes"],
    ]
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    for index, header in enumerate(headers):
        table.cell(0, index).text = header
        set_cell_shading(table.cell(0, index), "F2F4F7")
        for run in table.cell(0, index).paragraphs[0].runs:
            run.bold = True
    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            cells[index].text = value
    set_table_widths(table, [0.68, 0.60, 0.72, 0.66, 0.76, 1.18, 1.20, 0.58])
    set_table_font(table)
    p = doc.add_paragraph("N ≥1 counts people appearing in an included wave; N ≥2 counts people with at least two included waves. Intervals are positive-time consecutive scheduled-wave pairs or validated terminal-death intervals before model-specific complete-case restrictions. Cognition and function use non-overlapping inputs. KLoSA function records help dependence. * ELSA mortality follow-up was incomplete for the analytical period and was not treated as a valid death endpoint.")
    p.style = doc.styles["Caption"]

    doc.add_paragraph("Table 2. Principal results", style="Heading 1")
    headers = ["Outcome/analysis", "k", "Participant clusters", "Intervals", "Estimate (95% CI)", "I²"]
    rows = [
        ["Paired cognitive worsening", "6", "130,672", "361,562", "β 0.0459 (0.0243 to 0.0675)", "74.3%"],
        ["Paired functional worsening", "6", "130,672", "361,562", "β 0.0960 (0.0809 to 0.1111)", "41.8%"],
        ["Functional minus cognitive", "6", "130,672", "361,562", "β 0.0534 (0.0325 to 0.0742)", "51.6%"],
        ["Any cognitive transition", "6", "107,207", "266,127", "OR 1.01 (0.95 to 1.07)", "81.8%"],
        ["Any functional transition", "6", "107,207", "266,127", "OR 1.33 (1.27 to 1.40)", "64.9%"],
        ["Functional/cognitive ratio of ORs", "6", "107,207", "266,127", "1.32 (1.23 to 1.42)", "76.0%"],
    ]
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    for index, header in enumerate(headers):
        table.cell(0, index).text = header
        set_cell_shading(table.cell(0, index), "F2F4F7")
        for run in table.cell(0, index).paragraphs[0].runs:
            run.bold = True
    for row in rows:
        cells = table.add_row().cells
        for index, value in enumerate(row):
            cells[index].text = value
    set_table_widths(table, [1.55, 0.35, 0.85, 0.75, 2.25, 0.55])
    set_table_font(table)
    p = doc.add_paragraph("Primary continuous estimates use fixed-reference paired-domain GEE. Primary binary estimates use 20% target-occupancy states. Participant clusters and analytic intervals are reported separately. Principal models include available mental-health covariates. Random-effects pooling uses REML and Hartung-Knapp confidence intervals. Secondary and sensitivity analyses are reported in Supplementary Tables S9, S13 and S16.")
    p.style = doc.styles["Caption"]


def append_references_from_source(doc: Document) -> None:
    source = Document(SOURCE_MANUSCRIPT)
    references = []
    for paragraph in source.paragraphs:
        text = paragraph.text.strip()
        if re.match(r"^\d+\.\s", text):
            if text.startswith("17. "):
                text = "17. Gateway to Global Aging Data. Harmonized KLoSA Version E.2 (2006-2020). July 2023. doi: 10.34729/815E-WN35."
            elif text.startswith("20. "):
                text = "20. Viechtbauer W. Bias and efficiency of meta-analytic variance estimators in the random-effects model. J Educ Behav Stat 2005;30:261–93. doi: 10.3102/10769986030003261."
            references.append(text)
    references.extend([
        "27. Liang KY, Zeger SL. Longitudinal data analysis using generalized linear models. Biometrika 1986;73:13–22. doi: 10.1093/biomet/73.1.13.",
        "28. Mancl LA, DeRouen TA. A covariance estimator for GEE with improved small-sample properties. Biometrics 2001;57:126–34. doi: 10.1111/j.0006-341X.2001.00126.x.",
        "29. Hartung J, Knapp G. On tests of the overall treatment effect in meta-analysis with normally distributed responses. Stat Med 2001;20:1771–82. doi: 10.1002/sim.791.",
        "30. Robins JM, Finkelstein DM. Correcting for noncompliance and dependent censoring in an AIDS clinical trial with inverse probability of censoring weighted log-rank tests. Biometrics 2000;56:779–88. doi: 10.1111/j.0006-341X.2000.00779.x.",
    ])
    if references:
        doc.add_paragraph("References", style="Heading 1")
        for text in references:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.25)
            p.paragraph_format.first_line_indent = Inches(-0.25)
            p.paragraph_format.space_after = Pt(4)
            p.add_run(text)


def build(markdown: str, output: str, label: str, manuscript: bool = False) -> None:
    doc = Document()
    configure_document(doc, label)
    parse_markdown(doc, TEXT / markdown, manuscript=manuscript)
    if manuscript:
        append_manuscript_tables(doc)
        append_references_from_source(doc)
        add_continuous_line_numbers(doc)
    OUT.mkdir(parents=True, exist_ok=True)
    doc.save(OUT / output)


def main() -> None:
    build("manuscript_revised_working.md", "Manuscript_Revised.docx", "CMM cognitive-functional transitions", manuscript=True)
    build("supplementary_methods_revised_working.md", "Supplementary_Appendix_1.docx", "Supplementary Appendix 1 | Methods")


if __name__ == "__main__":
    main()
