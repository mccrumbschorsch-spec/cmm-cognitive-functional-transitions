# GitHub and Zenodo publishing guide

This repository is data-free. Do not add cohort CSV/DTA files, participant-level outputs, credentials, or machine-specific paths.

## 1. Choose the repository and licence

Recommended repository name: `cmm-cognitive-functional-transitions`.

Create an empty public GitHub repository under the account or organisation that should permanently own the project. Do not initialise it with a README, `.gitignore` or licence because those files already exist locally.

The authors must choose a software licence before publication. MIT is a common permissive choice for analysis code; select a different licence if institutional policy requires it. Add the chosen `LICENSE` file at the repository root.

## 2. Check the public package locally

From Terminal:

```bash
cd "/path/to/repository_ready"
find . -type f | sort
rg -n "/Users/|/Volumes/|D:\\\\|private_input/.*\\.csv" . \
  --glob '!SHA256SUMS.txt' \
  --glob '!aggregate_results/v3/analysis_manifest_public.json'
git check-ignore -v private_input/example.csv data/raw/example.dta
```

The first search should not reveal real local paths. The manifest intentionally contains repository-relative `private_input/<cohort>.csv` placeholders and input hashes, not participant data.

## 3. Initialise and push

Replace `YOUR_ACCOUNT` with the GitHub owner:

```bash
cd "/path/to/repository_ready"
git init -b main
git add .
git status --short
git commit -m "Public reproducibility package v1.0.0"
git remote add origin https://github.com/YOUR_ACCOUNT/cmm-cognitive-functional-transitions.git
git push -u origin main
```

Review the GitHub file list before making the release. No participant-level data should appear.

## 4. Create the archived release and DOI

1. Sign in to Zenodo and connect the same GitHub account.
2. Enable the new repository in Zenodo's GitHub settings.
3. On GitHub, create release `v1.0.0` from the `main` branch with a concise description stating that it corresponds to the revised manuscript.
4. Zenodo will archive the release and display a DOI. Use the DOI for the specific `v1.0.0` version in the manuscript; the concept DOI may additionally be recorded in the repository.

## 5. Insert the verified identifiers

After both identifiers resolve publicly, run from the submission-package root:

```bash
cd "/path/to/Revised_Submission_20260818"
python3 finalize_public_identifiers.py \
  --github-url https://github.com/YOUR_ACCOUNT/cmm-cognitive-functional-transitions \
  --doi 10.5281/zenodo.YOUR_DOI_NUMBER
```

Then rebuild the DOCX/PDF files and regenerate the checksum manifest. Do not type a placeholder URL or DOI into the manuscript.

## 6. Suggested manuscript wording after finalisation

> All harmonisation and analysis scripts, configuration files, aggregate outputs, model-completion records and software requirements are publicly available at [GitHub URL]. The archived version corresponding to this article is available at [DOI URL]. Participant-level cohort data remain subject to the access conditions of the source studies and are not redistributed.
