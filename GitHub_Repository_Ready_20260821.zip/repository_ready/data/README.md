# Data access and expected inputs

Participant-level data are not distributed in this repository.

The analysis uses deidentified data from:

- China Health and Retirement Longitudinal Study (CHARLS);
- English Longitudinal Study of Ageing (ELSA);
- Health and Retirement Study (HRS);
- Korean Longitudinal Study of Ageing (KLoSA);
- Mexican Health and Aging Study (MHAS);
- Survey of Health, Ageing and Retirement in Europe (SHARE).

Users must obtain each resource under its official public, registered or controlled-access terms. Harmonized releases used in the locked run are listed in `config/revision_config_filled_20260821.json` and Supplementary Table S1.

The private source tree supplied to `prepare_rebuild_inputs.py --source-root` must contain the cohort working files and source wave files used by the upstream processing workflow. The script resolves the project-specific cohort directories, writes standardised private CSV inputs and a scheduled response table, and never copies participant-level data into the repository.

The public manifest preserves SHA-256 hashes of the six locked private inputs while replacing machine-specific paths with `private_input/<cohort>.csv` placeholders.
