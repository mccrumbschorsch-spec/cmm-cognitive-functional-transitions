# Cardiometabolic multimorbidity and cognitive-functional transitions

This is the data-free reproducibility package for the 21 August 2026 major-revision rerun across CHARLS, ELSA, HRS, KLoSA, MHAS and SHARE.

## What is included

- complete harmonisation and analysis scripts;
- the locked cohort/variable configuration;
- regression tests and final-output validation;
- all non-disclosive cohort-level and pooled aggregate outputs;
- final manuscript figures and manuscript source text;
- submission-build scripts.

No participant-level cohort data are included or written by the analysis pipeline.

## Main analysis choices

- row-complete four-condition CMM4, with both endpoints required for change models and baseline CMM4 required for transition models;
- fixed-reference, non-overlapping cognitive and functional composites;
- exact interview-year/month timing, consecutive scheduled-wave pairs and validated terminal-death intervals;
- participant-clustered GEE;
- threshold-free paired continuous domain interaction as the primary domain test;
- cohort-wave 20% target occupancy for primary binary states;
- 15%, 25%, historical ±0.43, strict ±0.67 and persistent-state sensitivities;
- fixed reference-wave 20% cut-points applied unchanged to later waves;
- diabetes-plus-stroke and CMM3 excluding stroke exposures;
- temporal-boundary, ELSA/KLoSA exclusion and KLoSA ADL-only sensitivities;
- explicit counts below 0.5 years and above 5 years, with principal-model restriction to 0.5-5 years;
- mortality as an absorbing endpoint in five validated cohorts, including a 0.5-5-year terminal-death-interval sensitivity;
- non-death IPCW;
- REML/Hartung-Knapp pooling and complete model-failure tracking.

## Environment

Create a Python environment and install:

```bash
python -m pip install -r requirements.txt
```

KLoSA item extraction additionally requires R and the packages in `R_PACKAGES.txt`.

## Reproduction outline

Obtain the six cohort resources through their official access mechanisms. The expected upstream project tree is documented in `data/README.md`.

```bash
python analysis/prepare_rebuild_inputs.py \
  --source-root /path/to/cohort/source/tree \
  --output private_input

python analysis/revision_pipeline_v3.py \
  --config config/revision_config_filled_20260821.json \
  --input-root private_input \
  --output outputs_v3

python analysis/finalize_binary_and_prediction.py \
  --config config/revision_config_filled_20260821.json \
  --input-root private_input \
  --output outputs_v3 \
  --pipeline analysis/revision_pipeline_v3.py

python analysis/audit_klosa_item_reliability.py \
  --source-root /path/to/cohort/source/tree \
  --output outputs_v3/klosa_item_reliability_v3.csv

python analysis/final_additional_sensitivities.py \
  --config config/revision_config_filled_20260821.json \
  --input-root private_input \
  --main-results outputs_v3/cohort_model_results_v3.csv \
  --output additional_outputs

python analysis/validate_final_outputs.py outputs_v3

python analysis/make_revised_figures.py \
  --results outputs_v3 \
  --additional additional_outputs \
  --output figures
```

The KLoSA extractor is called by the input reconstruction workflow for the relevant source wave files; it can also be run directly as documented in its usage message.

## Verified final state

The locked run contains 76 principal pooled rows, 423 cohort-model rows and 438 registered cohort-model cells. Of these, 376 were estimated and 62 were failed/skipped with explicit reasons. The additional analysis file contains 59 pooled sensitivity rows. The primary paired continuous analysis contains 361,562 intervals; the primary 20% target-occupancy transition analysis contains 266,127 intervals.

## Data governance

The source studies have different public, registered and controlled-access terms. Do not commit cohort files, derived participant-level data, credentials or local paths. See `data/README.md`.

## Public deposit

This directory is ready for GitHub creation and archival. Follow `GITHUB_PUBLISHING_GUIDE.md`; after GitHub and Zenodo provide the final identifiers, run the repository finalisation script from the submission package and rebuild the manuscript. A software licence must be chosen by the authors before public release.
